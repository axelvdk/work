<?php
/* 
* 16/8/2011 ajout de nom et prenom dans crrerclient coord fac
  19/8/2011 ajout en session du login client meme si la connexion echoue pour recuperer dans le frmaulaire la donn�e
 *          dans connect_client
 *29/08/2011 ajout du chargement du panier a la connexion du client
 * 16/11/2011 debug avec modif du query deficient de consulter client fac
 */

/**
 * Description of ClientFactory
 *
 * @author C�dric
 */
class ClientFactory {

    public static function Connect_client($login,$pass) {



        if (!empty($login)AND(!empty($pass))) {
            include 'connect.php';
            $query= "SELECT id,login,pass,actif from client WHERE login='".mysql_real_escape_string($login)."' AND pass='".sha1(mysql_real_escape_string($pass))."'";
            $result=mysql_query($query) or die (mysql_error().' Erreur dans creer client: '.$query);
            if (mysql_numrows($result)>0) {
                $data= mysql_fetch_array($result);
                if($data['pass']== sha1($pass)) {
                    if($data['actif']==1) {
                        $_SESSION['id_client']=$data['id'];
                        $_SESSION['login_client']=$data['login'];

include_once './class/autoload.php';
    $panier = PanierFactory::ajout_sql();

                        header('location: '.$_SERVER['HTTP_REFERER'].'') ;
                        return true;
                    }
                    else {
                       
                        return 'NON_ACTIF';
                    }
                }

            }
           
            mysql_close();
        }
 $_SESSION['login_client']=$login;
    }


    public static function CreerClient($email,$login,$pass,$pass2,$nom,$prenom,$telephone,$fax,$lang,$actif,$last_ip,$last_connect) {




        $client= new Client();

        $client->setEmail($email);
        $client->setLogin($login);
        $client->setPass($pass,$pass2);
        $client->setNom($nom);
        $client->setPrenom($prenom);
        $client->setTelephone($telephone);
        $client->setFax($fax);
        $client->setLang($lang);

        include 'connect.php';


        if(empty($client->erreur)) {//on place en bdd


            $query="INSERT INTO client SET
                                    email='".mysql_real_escape_string($client->email)."',
                                    login='".mysql_real_escape_string($client->login)."',
                                    pass='".mysql_real_escape_string($client->pass)."',
                                    nom='".mysql_real_escape_string($client->nom)."',
                                    prenom='".mysql_real_escape_string($client->prenom)."',
                                    telephone='".mysql_real_escape_string($client->telephone)."',
                                    fax='".mysql_real_escape_string($client->fax)."',
                                    last_ip='".mysql_real_escape_string($last_ip)."',
                                    last_connect='".mysql_real_escape_string($last_connect)."',
                                    actif='".mysql_real_escape_string($actif)."',
                                    archive='0',
                                    lang='".mysql_real_escape_string($lang)."',
                                    type=2
";
            $result=mysql_query($query) or die (mysql_error().' Erreur dans creer client: '.$query);

            $client->setId(mysql_insert_id());

        }

        mysql_close();

        return $client;

    }

    public static function CreerClient_coord_fac($id_client,$societe,$nom,$prenom,$tva,$rue,$num,$boite,$cp,$commune,$pays,$actif) {

    //verifier unicite tva, si existe (sauf NA), supprimer le client avec l'ide recu

        $client_coord_fac=new Client_coord_fac();


        $client_coord_fac->setSociete($societe);
        $client_coord_fac->setNom($nom);
        $client_coord_fac->setPrenom($prenom);
        $client_coord_fac->setTva($tva);
        $client_coord_fac->setRue($rue);
        $client_coord_fac->setNum($num);
        $client_coord_fac->setBoite($boite);
        $client_coord_fac->setCp($cp);
        $client_coord_fac->setCommune($commune);
        $client_coord_fac->setPays($pays);
        $client_coord_fac->setActif($actif);
        $client_coord_fac->setId_client($id_client);




        if(empty($client_coord_fac->erreur)) {//on place en bdd
            include 'connect.php';
            $query="INSERT INTO client_coord_fac SET
                                    Societe='".mysql_real_escape_string($client_coord_fac->societe)."',
                                    nom='".mysql_real_escape_string($client_coord_fac->nom)."',
                                    prenom='".mysql_real_escape_string($client_coord_fac->prenom)."',
                                    tva='".mysql_real_escape_string($client_coord_fac->tva)."',
                                    rue='".mysql_real_escape_string($client_coord_fac->rue)."',
                                    num='".mysql_real_escape_string($client_coord_fac->num)."',
                                    boite='".mysql_real_escape_string($client_coord_fac->boite)."',
                                    cp='".mysql_real_escape_string($client_coord_fac->cp)."',
                                    commune='".mysql_real_escape_string($client_coord_fac->commune)."',
                                    pays='".mysql_real_escape_string($client_coord_fac->pays)."',
                                    actif='".mysql_real_escape_string($client_coord_fac->actif)."'
";
            $result=mysql_query($query) or die (mysql_error().' Erreur dans creer client_coord_fac: '.$query);

            $esclave=mysql_insert_id();

            $query="INSERT INTO client_coord_fac_lie SET
                                    maitre='".mysql_real_escape_string($id_client)."',
                                    esclave='".mysql_real_escape_string($esclave)."'
 ";

            $result=mysql_query($query) or die (mysql_error().' Erreur dans creer client_coord_fac: '.$query);

            $client_coord_fac->setId($esclave);

            mysql_close();
        }



        return $client_coord_fac;

    }

    
    public static function CreerClient_coord_livr($id_client,$societe,$contact,$gsm,$tva,$rue,$num,$boite,$cp,$commune,$pays,$actif) {

    //verifier unicite tva, si existe (sauf NA), supprimer le client avec l'ide recu

        $client_coord_livr=new Client_coord_livr();


        $client_coord_livr->setSociete($societe);
        $client_coord_livr->setContact($contact);
        $client_coord_livr->setGsm_contact($gsm);
        $client_coord_livr->setRue($rue);
        $client_coord_livr->setNum($num);
        $client_coord_livr->setBoite($boite);
        $client_coord_livr->setCp($cp);
        $client_coord_livr->setCommune($commune);
        $client_coord_livr->setPays($pays);
        $client_coord_livr->setActif($actif);
        $client_coord_livr->setId_client($id_client);



      
        if(empty($client_coord_livr->erreur)) {//on place en bdd
            include 'connect.php';
            $query="INSERT INTO client_coord_livr SET
                                    Societe='".mysql_real_escape_string($client_coord_livr->societe)."',
                                    contact='".mysql_real_escape_string($client_coord_livr->contact)."',
                                    telephone_contact='".mysql_real_escape_string($client_coord_livr->gsm)."',
                                    rue='".mysql_real_escape_string($client_coord_livr->rue)."',
                                    num='".mysql_real_escape_string($client_coord_livr->num)."',
                                    boite='".mysql_real_escape_string($client_coord_livr->boite)."',
                                    cp='".mysql_real_escape_string($client_coord_livr->cp)."',
                                    commune='".mysql_real_escape_string($client_coord_livr->commune)."',
                                    pays='".mysql_real_escape_string($client_coord_livr->pays)."',
                                    actif='".mysql_real_escape_string($client_coord_livr->actif)."'
";
            $result=mysql_query($query) or die (mysql_error().' Erreur dans creer client_coord_livr: '.$query);

            $esclave=mysql_insert_id();

            $query="INSERT INTO client_coord_livr_lie SET
                                    maitre='".mysql_real_escape_string($id_client)."',
                                    esclave='".mysql_real_escape_string($esclave)."'
 ";

            $result=mysql_query($query) or die (mysql_error().' Erreur dans creer client_coord_livr: '.$query);

            $client_coord_livr->setId($esclave);

            mysql_close();
        }



        return $client_coord_livr;

    }

    
    public static function ModifClient_coord_fac($id_client,$id_client_lie,$societe,$nom, $prenom,$tva,$rue,$num,$boite,$cp,$commune,$pays,$actif) {

    //verifier unicite tva, si existe (sauf NA), supprimer le client avec l'ide recu
 $query="SELECT * from client_coord_fac_lie where
                                    maitre='".mysql_real_escape_string($id_client)."' AND
                                    esclave='".mysql_real_escape_string($id_client_lie)."'
 ";

            $result=mysql_query($query) or die (mysql_error().' Erreur dans creer client_coord_fac: '.$query);


      


        if(mysql_num_rows($result)>0) {//on place en bdd
            
           
            include 'connect.php';
            $query="update client_coord_fac SET
                                    Societe='".mysql_real_escape_string($societe)."',
                                    nom='".mysql_real_escape_string($nom)."',
                                    prenom='".mysql_real_escape_string($prenom)."',
                                    tva='".mysql_real_escape_string($tva)."',
                                    rue='".mysql_real_escape_string($rue)."',
                                    num='".mysql_real_escape_string($num)."',
                                    boite='".mysql_real_escape_string($boite)."',
                                    cp='".mysql_real_escape_string($cp)."',
                                    commune='".mysql_real_escape_string($commune)."',
                                    pays='".mysql_real_escape_string($pays)."',
                                    actif='".mysql_real_escape_string($actif)."'
                                        Where id='".mysql_real_escape_string($id_client_lie)."'
";
            $result=mysql_query($query) or die (mysql_error().' Erreur dans creer client_coord_fac: '.$query);

       echo $query;

           

            mysql_close();
        }





    }

    
    public static function Client_Change_PW($identifiant) {

        include_once './lang/'.$_SESSION['lang'].'/lang_class_clientfactory.php';

        if($identifiant!='') {
            include 'connect.php';
            //
            ////rechercher ds bd l'equivalent id login de e-mail + time, faire md5 avec les 3 donn�es

            $query="    SELECT  id, login, email
                    FROM client
                    WHERE login = '".mysql_real_escape_string($identifiant)."'
                    OR email = '".mysql_real_escape_string($identifiant)."'
                    ";

            $result=mysql_query($query) or die (mysql_error().' Erreur dans Client_Change_PW: '.$query);

            if (mysql_numrows($result)==1) {
                $donnee=mysql_fetch_array($result);

                //le sha1 avec al�atoire
                // $ctrl=sha1($login.$id.rand(1000, 5000));
                define('ALPHABET','azertyuipqsdfghjklmwxcvbnAZERTYUPQSDFGHJKLMWXCVBN1234567890'); //Entrez les caract�res que vous voulez
                $longueur=8;
                $ctrl=substr(str_shuffle(str_repeat(ALPHABET,$longueur)),0,$longueur);


                $query = "	INSERT INTO client_change_pw
					SET 
					id_client = '".$donnee['id']."',
					login = '".$donnee['login']."',
					ctrl = '".$ctrl."',
					date = '".time()."'
					
				";



                $result=mysql_query($query) or die (mysql_error().' Erreur dans Client_Change_PW: '.$query);

                //ecrire dans newemail les donn�es avec les donn�e de temps


                $Destinataire = $donnee['email'];
                $Sujet = _CLIENT_CHANGE_PW_MAIL_TITRE;

                $From  = "From:".MAIL_ADMIN."\n";
                $From .= "MIME-version: 1.0\n";
                $From .= "Content-type: text/html; charset= iso-8859-1\n";

                $Message = "

<html>
<b>"._CLIENT_CHANGE_PW_MAILCONTENU." ".SITE_ADRESS." </b><br><br>"._CLIENT_CHANGE_PW_MAILCONTENU2."
<br><br>

"._CLIENT_CHANGE_PW_LOGIN." ".$donnee['login']."<br>
"._CLIENT_CHANGE_PW_CTRL." ".$ctrl."<br>

<p><a href=\"http://".SITE_ADRESS."/".$_SESSION['lang']."-modifpw1-".$donnee['login']."-".$ctrl.".html\">"._CLIENT_CHANGE_PW_MAILLIEN1."</a>"._CLIENT_CHANGE_PW_MAILLIENDEF1."</p><br>

<p><a href=\"http://".SITE_ADRESS."/".$_SESSION['lang']."-modifpw0-".$donnee['login']."-".$ctrl.".html\">"._CLIENT_CHANGE_PW_MAILLIEN2."</a>"._CLIENT_CHANGE_PW_MAILLIENDEF2."</p>";

                ;

                if(!mail($Destinataire,$Sujet,$Message,$From)) {

                    $message=_CLIENT_CHANGE_PW_MESSAGE1;

                }

                else {

                    $message=_CLIENT_CHANGE_PW_MESSAGE2;

                }
            }

            elseif (mysql_numrows($result)==0) {

                $message=_CLIENT_CHANGE_PW_MESSAGE1;
            }
            //si pas de concordance (log n'existe pas
            return $message;

        }

    }



    public static function Client_Change_PW_Confirmation($action,$login,$ctrl,$pass,$pass2) {

        include_once './lang/'.$_SESSION['lang'].'/lang_class_clientfactory.php';

        $client= new Client();

        include 'connect.php';


        //supprimer les requetes de plus de 48heures
        $t=time()- (48 * 60 * 60);



        $query="DELETE FROM client_change_pw WHERE date <'".$t."' ";

        $result=mysql_query($query) or die (mysql_error().' Erreur dans Client_Change_PW_Confirmation: '.$query);


        if ($action=='annulation') {
            $query="DELETE FROM client_change_pw WHERE login='".$login."' ";

            $result=mysql_query($query) or die (mysql_error().' Erreur dans Client_Change_PW_Confirmation: '.$query);


            $client->setErreur(_CLIENT_CHANGE_PW_CONFIRMATION_ANNULATION);

        }

        elseif($action=='valide') {

            $client->setPass($pass,$pass2);


            if(empty($client->erreur)) {//on place en bdd

                $query=mysql_query("SELECT * FROM client_change_pw WHERE login='".$login."' ORDER By date DESC");
                $data= mysql_fetch_array($query);



                //comparaison si different on bloque

                if ($ctrl != $data['ctrl']) {


                    $client->setErreur(_CLIENT_CHANGE_PW_CONFIRMATION_NUL);


                }

                elseif($ctrl == $data['ctrl']) {
                //si on annule on anule...






                    $query2="DELETE FROM client_change_pw WHERE login='".$login."' ";

                    $result=mysql_query($query2) or die (mysql_error().' Erreur dans Client_Change_PW_Confirmation: '.$query);




                    $query2="UPDATE client SET
                            pass='".mysql_real_escape_string($client->pass)."'
                            WHERE login='".$login."' ";

                    $result=mysql_query($query2) or die (mysql_error().' Erreur dans Client_Change_PW_Confirmation: '.$query);



                    $client->setErreur(_CLIENT_CHANGE_PW_CONFIRMATION_OK);
                }
            }
        }


        mysql_close();


        return $client;
    }




    public static function ConsulterClient_fac($id) {

        include 'connect.php';


        $query="Select
                    client_coord_fac.id,
                    client_coord_fac.societe,
                    client_coord_fac.nom,
                    client_coord_fac.prenom,
                    client_coord_fac.tva,
                    client_coord_fac.rue,
                    client_coord_fac.num,
                    client_coord_fac.boite,
                    client_coord_fac.cp,
                    client_coord_fac.commune,
                    client_coord_fac.Pays

                FROM client_coord_fac_lie
                
                LEFT JOIN client_coord_fac 
                ON client_coord_fac.id=client_coord_fac_lie.esclave
                
                WHERE client_coord_fac_lie.maitre='".$id."'
                    
                ORDER BY client_coord_fac.id DESC
        ";

        $result=mysql_query($query);
        
        if(mysql_num_rows($result)>0){
      
            while ($data=mysql_fetch_array($result)){
        $client_coord_fac=new Client_coord_fac(); 
        $client_coord_fac->setId_client_fac($data[id]);     
        $client_coord_fac->setSociete($data[societe]);
        $client_coord_fac->setNom($data[nom]);
        $client_coord_fac->setPrenom($data[prenom]);
        $client_coord_fac->setTva($data[tva]);
        $client_coord_fac->setRue($data[rue]);
        $client_coord_fac->setNum($data[num]);
        $client_coord_fac->setBoite($data[boite]);
        $client_coord_fac->setCp($data[cp]);
        $client_coord_fac->setCommune($data[commune]);
        $client_coord_fac->setPays($data[Pays]);
        
        $client_coord_fac_tab[]=$client_coord_fac;
        
            }

        }
        

        
          return $client_coord_fac_tab;
    }

    
    
    public static function ConsulterClient_livr($id) {

        include 'connect.php';


        $query="Select
                    client_coord_livr.id,
                    client_coord_livr.societe,
                    client_coord_livr.contact,
                    client_coord_livr.telephone_contact,
                    client_coord_livr.note_livraison,
                    client_coord_livr.rue,
                    client_coord_livr.num,
                    client_coord_livr.boite,
                    client_coord_livr.cp,
                    client_coord_livr.commune,
                    client_coord_livr.Pays

                FROM client_coord_livr_lie
                
                LEFT JOIN client_coord_livr 
                ON client_coord_livr.id=client_coord_livr_lie.esclave
                
                WHERE client_coord_livr_lie.maitre='".$id."'
                    
                ORDER BY client_coord_livr.id DESC
        ";

        $result=mysql_query($query);
  
        if(mysql_num_rows($result)>0){
      
            while ($data=mysql_fetch_array($result)){
        $client_coord_livr=new Client_coord_livr(); 
        $client_coord_livr->setId_client_livr($data[id]);     
        $client_coord_livr->setSociete($data[societe]);
        $client_coord_livr->setContact($data[contact]);
        $client_coord_livr->setGsm_contact($data[telephone_contact]);
        $client_coord_livr->setNote_livr($data[note_livraison]);
        //$client_coord_fac->setTva($data[tva]);
        $client_coord_livr->setRue($data[rue]);
        $client_coord_livr->setNum($data[num]);
        $client_coord_livr->setBoite($data[boite]);
        $client_coord_livr->setCp($data[cp]);
        $client_coord_livr->setCommune($data[commune]);
        $client_coord_livr->setPays($data[Pays]);
        
        $client_coord_fac_livr[]=$client_coord_livr;
        
            }

        }
        

        
          return $client_coord_fac_livr;
    }
} 
?>
