<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Utilitaire_galerieclass
 *
 * @author C�dric
 */
class Utilitaire_galerie {

    private




        pas utiliser!!!!!!!!!!!!!!!!!!!!!!!!!!!!!



        if (!isset($limit_inf) OR ($limit_inf)){$limit_inf=0;}

$limit_inf_moins=$limit_inf-$nbr_resultat_parpage;
$limit_inf_plus=$limit_inf+$nbr_resultat_parpage;
$nbr_page=ceil($nbr_resultat/$nbr_resultat_parpage);
$numero_page=(($limit_inf/$nbr_resultat_parpage)+1);

$this->limit_inf_moins=$limit_inf_moins;

return $this;


    }
}
?>
