<?php

/*
 *
 * 16mai2011 modif bug nbarticle dans
 *20/10/11 rajout le la gestion du multipliant, qui permet de travailler un article par qte de caisse
 * 25/11/11 rajout de $numserie = $id_product.'_-_'.$id_model; et $id_model=0 si vide dans ajoutarticle pour bug repetition de l'article dns le panier quand on se connecte 
 * 23/1/12 rajout de mysql_real_escape_string dans les divers insert mysql...
 */

/**
 * Description of PanierFactoryclass
 *
 * @author Cédric
 */
class PanierFactory {

    static function construct() {


        if (isset($_SESSION['panier'])) {
            $var = unserialize($_SESSION['panier']);
        } else {
            $var = new Panier();
        }

        return $var;
    }

    static function ajout_sql() {
        $var = self::construct();

        if (file_exists('./connect.php')) {
            include './connect.php';
        } else {
            include '../connect.php';
        }


        if (!isset($var->num_dossier)) {

            //si pas de numero de dossier dans l'objet, on va chercher le dernier dossier en encodage

            $query = "SELECT dossier.id
	    FROM dossier
	    LEFT JOIN dossier_detail ON dossier_detail.id_dossier = dossier.id
	    WHERE id_client ='" . $_SESSION['id_client'] . "'
	    AND dossier_detail.etat = '10'
	    ORDER BY dossier.id DESC
	    LIMIT 1";


            $result = mysql_query($query) or die(mysql_error() . ' Erreur dans ajout sql: ' . $query);
            if (mysql_num_rows($result) > 0) {

                $data = mysql_fetch_array($result);
                $id_dossier = $data['id'];

                // on doit recreer l'objet


                $query = "SELECT dossier_detail.id_art,
				dossier_detail.ref_art,
				dossier_detail.ref_model,
				dossier_detail.nom_art,
				dossier_detail.nom_model,
                                dossier_detail.id_model,
                                dossier_detail.qtee,
                                dossier_detail.prix,
                                dossier_detail.tva
                         FROM dossier_detail

                         LEFT JOIN dossier
                         ON dossier.id=dossier_detail.id_dossier

                         LEFT JOIN element
                         ON element.id=dossier_detail.id_art

                         LEFT JOIN element AS model
                         ON model.id=dossier_detail.id_model

                         WHERE dossier.id='" . $id_dossier . "'
			   AND dossier_detail.etat='10';
";




                $result = mysql_query($query) or die(mysql_error() . ' Erreur dans ajout sql: ' . $query);
                while ($data = mysql_fetch_array($result)) {
                    if($data['id_model']==''){$data['id_model']=0;}
                    $numserie = $data['id_art'] . '_-_' . $data['id_model'];
          
                    $quantite = $data['qtee'];
                    $montantHT = $data['prix'];
                    $tva = $data['tva'];
                    if (!empty($numserie)) {

                        $var->article[$numserie]['ref'] = $data['ref_art'];
                        $var->article[$numserie]['nom'] = $data['nom_art'];
                        $var->article[$numserie]['ref_model'] = $data['ref_model'];
                        $var->article[$numserie]['nom_model'] = $data['nom_model'];

                        if ($var->article[$numserie])
                            $var->article[$numserie]['qte'] += $quantite;
                        else {
                            $var->article[$numserie]['qte'] = $quantite;
                        }

                        if (isset($var->calculmontant) && $var->calculmontant == true) {
                            $var->article[$numserie]['prix'] = $montantHT;
                            $var->article[$numserie]['tva'] = $tva;
                            $var->CalculMontantArticle($numserie, $var->article[$numserie]['prix'], $quantite);
                            $var->CalculTotal($var->article[$numserie]['prix'] * $quantite);
                        }
                    }

                    $var->nbarticle = $var->nbarticle + $quantite;
                }
            } else {
                //si il n'existe pas: on cr�e un nouveau dossier

                $query = "INSERT INTO dossier SET
                                    id_client='" . $_SESSION['id_client'] . "',
                                    date_crea='" . date("d/m/y H:i:s") . "',
                                    ip='" . $_SERVER["REMOTE_ADDR"] . "'
                                    ";
                $result = mysql_query($query) or die(mysql_error() . ' Erreur dans ajot sql: ' . $query);
                $id_dossier = mysql_insert_id();
            }

            $var->num_dossier = $id_dossier;
        }

        //detail du dossier
        //on vide le dossier correction d'une eventuelle difference entre l'objet et la bdd

        $query = "DELETE FROM dossier_detail WHERE
                           id_dossier='" . $var->num_dossier . "' AND etat='10'
                                                      ";

        $result = mysql_query($query) or die(mysql_error() . ' Erreur dans ajout sql: ' . $query);

        $query = "ALTER TABLE dossier_detail
AUTO_INCREMENT=1  ";

        $result = mysql_query($query) or die(mysql_error() . ' Erreur dans ajout sql: ' . $query);

        foreach ($var->article as $clee => $valeur) {
            $chaine = explode('_-_', $clee, 2);

            $id_product = $chaine[0]; //id de l'element
            $id_model = $chaine[1]; //modele qui conditionne le prix
            if($id_model==''){$id_model=0;}
            $query = "INSERT INTO dossier_detail SET
                           id_dossier='" . mysql_real_escape_string($var->num_dossier) . "',
                           id_art='" . mysql_real_escape_string($id_product) . "',
                           id_model='" . mysql_real_escape_string($id_model) . "',
                           ref_art='" . mysql_real_escape_string($valeur['ref']) . "',
			   ref_model='" . mysql_real_escape_string($valeur['ref_model']) . "',
                            nom_art='" . mysql_real_escape_string($valeur['nom']) . "',
				nom_model='" . mysql_real_escape_string($valeur['nom_model']) . "',
                           qtee='" . mysql_real_escape_string($valeur['qte']) . "',
                           prix='" . mysql_real_escape_string($valeur['prix']) . "',
                               tva='" . mysql_real_escape_string($valeur['tva']) . "',
                           etat='10',
                           date_crea='" . date("d/m/y H:i:s") . "',
                           ip='" . $_SERVER["REMOTE_ADDR"] . "'
  ON DUPLICATE KEY UPDATE
                        qtee='" . mysql_real_escape_string($var->article[$numserie]['qte']) . "',
                           date_crea='" . date("d/m/y H:i:s") . "',
                           ip='" . $_SERVER["REMOTE_ADDR"] . "'
                           
                           ";

            $result = mysql_query($query) or die(mysql_error() . ' Erreur dans ajout sql: ' . $query);
        }


        return $var;
    }

    static function consulterPanier() {
        $var = self::construct();
        return $var;
    }
    
    static function supprimerPanier() {

        $var = self::construct();

        if (file_exists('./connect.php')) {
            include './connect.php';
        } else {
            include '../connect.php';
        }
        
          $query = "DELETE FROM dossier_detail WHERE
                           id_dossier='" . $var->num_dossier . "' AND etat='10'
                                                      ";

        $result = mysql_query($query) or die(mysql_error() . ' Erreur dans supprimerl: ' . $query);
        
         $query2 = "DELETE FROM dossier WHERE
                           id='" . $var->num_dossier . "'
                                                      ";

        $result2 = mysql_query($query2) or die(mysql_error() . ' Erreur dans supprimer: ' . $query2);
        
        
    }
    

    // Ajoute un article dans le Panier
    static function ajouterArticle($numserie, $quantite, $montantHT = 0, $tva = 21) {

        $quantite = str_replace(',', '.', $quantite);
        if (!is_numeric($quantite)) {
            $quantite = 1;
        }


        $var = self::construct();



        if (isset($_SESSION['id_client'])) {
            if (file_exists('./connect.php')) {
                include './connect.php';
            } else {
                include '../connect.php';
            }

            $chaine = explode('_-_', $numserie, 2);

            $id_product = $chaine[0]; //id de l'element
             $query_p = "SELECT 
                                element.nom_" . $_SESSION['lang'] . " AS nom_art,
                                element.ref, 
                                element_unite_vente.multipliant
                        FROM element
                        LEFT JOIN element_unite_vente
                        ON element_unite_vente.id=element.unite_vente
                        
                        WHERE element.id='" . $id_product . "'
                       ";
            $result_p = mysql_query($query_p);
            $data_p = mysql_fetch_array($result_p);

            $nom_art = $data_p['nom_art'];
            $ref_art = $data_p['ref'];
            $id_model = $chaine[1]; //modele qui conditionne le prix
            if($id_model==''){$id_model=0;}
            $numserie = $id_product.'_-_'.$id_model;
            
            if (!is_null($id_model) AND $id_model != 0) {

                $query_m = "SELECT nom_" . $_SESSION['lang'] . " AS nom_mod,ref FROM element WHERE id='" . $id_model . "'";
                $result_m = mysql_query($query_m);
                $data_m = mysql_fetch_array($result_m);
                $ref_model = $data_m['ref'];
                $nom_model = $data_m['nom_mod'];
            }
            $var->article[$numserie]['nom'] = $nom_art;
            $var->article[$numserie]['ref'] = $ref_art;
            $var->article[$numserie]['nom_model'] = $nom_model;
            $var->article[$numserie]['ref_model'] = $ref_model;

            $query = "INSERT INTO dossier_detail SET
                           id_dossier='" . mysql_real_escape_string($var->num_dossier) . "',
                           id_art='" . mysql_real_escape_string($id_product) . "',
                           id_model='" . mysql_real_escape_string($id_model) . "',
                           ref_art='" . mysql_real_escape_string($ref_art ). "',
			       ref_model='" . mysql_real_escape_string($ref_model) . "',
                            nom_art='" . mysql_real_escape_string($nom_art) . "',
				nom_model='" . mysql_real_escape_string($nom_model) . "',
                           qtee='" . mysql_real_escape_string($quantite) . "',
                           etat='10',
                           date_crea='" . date("d/m/y H:i:s") . "',
                           ip='" . $_SERVER["REMOTE_ADDR"] . "'
                    ON DUPLICATE KEY UPDATE
                        qtee='" . mysql_real_escape_string($var->article[$numserie]['qte']) . "',
                           date_crea='" . date("d/m/y H:i:s") . "',
                           ip='" . $_SERVER["REMOTE_ADDR"] . "'
                           ";

            $result = mysql_query($query) or die(mysql_error() . ' Erreur dans creer client: ' . $query);
        }

///////
        else {
            if (file_exists('./connect.php')) {
                include './connect.php';
            } else {
                include '../connect.php';
            }

            $chaine = explode('_-_', $numserie, 2);

            $id_product = $chaine[0]; //id de l'element
            $query_p = "SELECT 
                                element.nom_" . $_SESSION['lang'] . " AS nom_art,
                                element.ref, 
                                element_unite_vente.multipliant
                        FROM element
                        LEFT JOIN element_unite_vente
                        ON element_unite_vente.id=element.unite_vente
                        
                        WHERE element.id='" . $id_product . "'
                       ";
            
           
            $result_p = mysql_query($query_p);
            $data_p = mysql_fetch_array($result_p);

            $nom_art = $data_p['nom_art'];
            $ref_art = $data_p['ref'];
            $id_model = $chaine[1]; //modele qui conditionne le prix
            if($id_model==''){$id_model=0;}
            $numserie = $id_product.'_-_'.$id_model;
            if (!is_null($id_model) AND $id_model != 0) {

                $query_m = "SELECT nom_" . $_SESSION['lang'] . " AS nom_mod,ref FROM element WHERE id='" . $id_model . "'";
                $result_m = mysql_query($query_m);
                $data_m = mysql_fetch_array($result_m);

                $ref_model = $data_m['ref'];
                $nom_model = $data_m['nom_mod'];
            }
            
            $var->article[$numserie]['nom'] = $nom_art;
            $var->article[$numserie]['ref'] = $ref_art;
            $var->article[$numserie]['nom_model'] = $nom_model;
            $var->article[$numserie]['ref_model'] = $ref_model;
        } 
        
if($data_p['multipliant']!=0){
     $qua=$quantite/$data_p['multipliant'];
                $qua=ceil($qua);
                $quantite=$qua*$data_p['multipliant'];
   
}
 
        if (!empty($numserie)) {
            if ($var->article[$numserie])
                $var->article[$numserie]['qte'] += $quantite;
            else {
                $var->article[$numserie]['qte'] = $quantite;
            }

            if (isset($var->calculmontant) && $var->calculmontant == true) {
                $var->article[$numserie]['prix'] = $montantHT;
                $var->article[$numserie]['tva'] = $tva;
                $var->CalculMontantArticle($numserie, $var->article[$numserie]['prix'], $quantite);
                $var->CalculTotal($var->article[$numserie]['prix']);
            }
        $var->article[$numserie]['multipliant'] = $data_p['multipliant'];
        
        }

        
        $var->nbarticle = $var->nbarticle + $quantite;


        return $var;
    }

    // Supprime un article du Panier
    static function supprimerArticle($numserie) {

        $var = self::construct();
        if (!empty($numserie) && $var->article[$numserie]) {
            if (isset($var->calculmontant) && $var->calculmontant == true) {
                $var->CalculTotal(- $var->article[$numserie]['montantHT']);
            }
            $var->nbarticle = $var->nbarticle - $var->article[$numserie]['qte'];
            unset($var->article[$numserie]);
        }
        return $var;
    }

    // Met � jour la quantite d'un article s�lectionn� dans le Panier
    static function miseAJourQteArticle($numserie, $quantite) {

        $quantite = str_replace(',', '.', $quantite);
        if (!is_numeric($quantite)) {
            $quantite = 1;
        }


        $var = self::construct();

        if (($quantite) < 0) {
            $quantite = 0;
        }

        if (!empty($numserie) && $var->article[$numserie]) {
            if($var->article[$numserie]['multipliant']!=0){
                
                $qua=$quantite/$var->article[$numserie]['multipliant'];
                $qua=ceil($qua);
                $quantite=$qua*$var->article[$numserie]['multipliant'];
                
                }
            if (isset($var->calculmontant) && $var->calculmontant == true) {
                
                
                $diff = $quantite - $var->article[$numserie]['qte'];
                $var->CalculMontantArticle($numserie, $var->article[$numserie]['prix'], $diff);
                $diff *= $var->article[$numserie]['prix'];
                $var->CalculTotal($diff);
            }
            $var->nbarticle = $var->nbarticle - $var->article[$numserie]['qte'] + $quantite;
            
            $var->article[$numserie]['qte'] = $quantite;
        }

        if (($var->article[$numserie]['qte']) <= 0) {
            unset($var->article[$numserie]);
        }
        return $var;
    }

}

?>
